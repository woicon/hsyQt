/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_3;
    QPushButton *pushButton_10;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_7;
    QPushButton *pushButton_12;
    QPushButton *s;
    QPushButton *pushButton_9;
    QPushButton *pushButton_14;
    QPushButton *pushButton_8;
    QPushButton *pushButton_11;
    QPushButton *pushButton_15;
    QPushButton *pushButton_6;
    QTabWidget *tabWidget;
    QWidget *tab_2;
    QGroupBox *groupBox;
    QWidget *tab;
    QPushButton *pushButton_13;
    QComboBox *comboBox;
    QWidget *widget;
    QWidget *formLayoutWidget;
    QFormLayout *formLayout;
    QLabel *Label;
    QLineEdit *LineEdit;
    QWidget *widget_2;
    QWidget *formLayoutWidget_2;
    QFormLayout *formLayout_2;
    QLabel *Label_2;
    QLineEdit *LineEdit_2;
    QWidget *widget_3;
    QWidget *formLayoutWidget_3;
    QFormLayout *formLayout_3;
    QLabel *Label_3;
    QLineEdit *LineEdit_3;
    QWidget *widget_4;
    QPushButton *pushButton_16;
    QPushButton *pushButton_17;
    QLabel *label_4;
    QWidget *widget_5;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(700, 380);
        MainWindow->setAutoFillBackground(false);
        MainWindow->setStyleSheet(QStringLiteral("background:rgbrgb(255, 255, 255);border:none"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayoutWidget = new QWidget(centralWidget);
        gridLayoutWidget->setObjectName(QStringLiteral("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(370, 40, 331, 341));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setSpacing(0);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        gridLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_4 = new QPushButton(gridLayoutWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        QSizePolicy sizePolicy(QSizePolicy::Ignored, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(pushButton_4->sizePolicy().hasHeightForWidth());
        pushButton_4->setSizePolicy(sizePolicy);
        pushButton_4->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_4->setLayoutDirection(Qt::LeftToRight);
        pushButton_4->setAutoFillBackground(false);
        pushButton_4->setStyleSheet(QStringLiteral("color:rgb(68, 68, 68);border:1px solid rgb(220, 220, 220);border-radius:0;font-size:28px;"));
        pushButton_4->setAutoDefault(false);

        gridLayout->addWidget(pushButton_4, 0, 1, 1, 1);

        pushButton_5 = new QPushButton(gridLayoutWidget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        sizePolicy.setHeightForWidth(pushButton_5->sizePolicy().hasHeightForWidth());
        pushButton_5->setSizePolicy(sizePolicy);
        pushButton_5->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_5->setLayoutDirection(Qt::LeftToRight);
        pushButton_5->setAutoFillBackground(false);
        pushButton_5->setStyleSheet(QStringLiteral("color:rgb(68, 68, 68);border:1px solid rgb(220, 220, 220);border-radius:0;font-size:28px;"));
        pushButton_5->setAutoDefault(false);

        gridLayout->addWidget(pushButton_5, 1, 1, 1, 1);

        pushButton_3 = new QPushButton(gridLayoutWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        sizePolicy.setHeightForWidth(pushButton_3->sizePolicy().hasHeightForWidth());
        pushButton_3->setSizePolicy(sizePolicy);
        pushButton_3->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_3->setLayoutDirection(Qt::LeftToRight);
        pushButton_3->setAutoFillBackground(false);
        pushButton_3->setStyleSheet(QStringLiteral("color:rgb(68, 68, 68);border:1px solid rgb(220, 220, 220);border-radius:0;font-size:28px;"));
        pushButton_3->setAutoDefault(false);

        gridLayout->addWidget(pushButton_3, 0, 2, 1, 1);

        pushButton_10 = new QPushButton(gridLayoutWidget);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        sizePolicy.setHeightForWidth(pushButton_10->sizePolicy().hasHeightForWidth());
        pushButton_10->setSizePolicy(sizePolicy);
        pushButton_10->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_10->setLayoutDirection(Qt::LeftToRight);
        pushButton_10->setAutoFillBackground(false);
        pushButton_10->setStyleSheet(QStringLiteral("color:rgb(68, 68, 68);border:1px solid rgb(220, 220, 220);border-radius:0;font-size:14px;"));
        pushButton_10->setAutoDefault(false);

        gridLayout->addWidget(pushButton_10, 0, 3, 1, 1);

        pushButton = new QPushButton(gridLayoutWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        sizePolicy.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy);
        pushButton->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton->setLayoutDirection(Qt::LeftToRight);
        pushButton->setAutoFillBackground(false);
        pushButton->setStyleSheet(QStringLiteral("color:rgb(68, 68, 68);border:1px solid rgb(220, 220, 220);border-radius:0;font-size:28px;"));
        pushButton->setAutoDefault(false);

        gridLayout->addWidget(pushButton, 0, 0, 1, 1);

        pushButton_2 = new QPushButton(gridLayoutWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        sizePolicy.setHeightForWidth(pushButton_2->sizePolicy().hasHeightForWidth());
        pushButton_2->setSizePolicy(sizePolicy);
        pushButton_2->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_2->setLayoutDirection(Qt::LeftToRight);
        pushButton_2->setAutoFillBackground(false);
        pushButton_2->setStyleSheet(QStringLiteral("color:rgb(68, 68, 68);border:1px solid rgb(220, 220, 220);border-radius:0;font-size:28px;"));
        pushButton_2->setAutoDefault(false);

        gridLayout->addWidget(pushButton_2, 1, 0, 1, 1);

        pushButton_7 = new QPushButton(gridLayoutWidget);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        sizePolicy.setHeightForWidth(pushButton_7->sizePolicy().hasHeightForWidth());
        pushButton_7->setSizePolicy(sizePolicy);
        pushButton_7->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_7->setLayoutDirection(Qt::LeftToRight);
        pushButton_7->setAutoFillBackground(false);
        pushButton_7->setStyleSheet(QStringLiteral("color:rgb(68, 68, 68);border:1px solid rgb(220, 220, 220);border-radius:0;font-size:28px;"));
        pushButton_7->setAutoDefault(false);

        gridLayout->addWidget(pushButton_7, 2, 0, 1, 1);

        pushButton_12 = new QPushButton(gridLayoutWidget);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        sizePolicy.setHeightForWidth(pushButton_12->sizePolicy().hasHeightForWidth());
        pushButton_12->setSizePolicy(sizePolicy);
        pushButton_12->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_12->setLayoutDirection(Qt::LeftToRight);
        pushButton_12->setAutoFillBackground(false);
        pushButton_12->setStyleSheet(QStringLiteral("color:rgb(68, 68, 68);border:1px solid rgb(220, 220, 220);border-radius:0;font-size:28px;"));
        pushButton_12->setAutoDefault(false);

        gridLayout->addWidget(pushButton_12, 3, 1, 1, 1);

        s = new QPushButton(gridLayoutWidget);
        s->setObjectName(QStringLiteral("s"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Ignored);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(s->sizePolicy().hasHeightForWidth());
        s->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(s, 2, 3, 2, 1);

        pushButton_9 = new QPushButton(gridLayoutWidget);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        sizePolicy.setHeightForWidth(pushButton_9->sizePolicy().hasHeightForWidth());
        pushButton_9->setSizePolicy(sizePolicy);
        pushButton_9->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_9->setLayoutDirection(Qt::LeftToRight);
        pushButton_9->setAutoFillBackground(false);
        pushButton_9->setStyleSheet(QStringLiteral("color:rgb(68, 68, 68);border:1px solid rgb(220, 220, 220);border-radius:0;font-size:28px;"));
        pushButton_9->setAutoDefault(false);

        gridLayout->addWidget(pushButton_9, 2, 2, 1, 1);

        pushButton_14 = new QPushButton(gridLayoutWidget);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));
        sizePolicy.setHeightForWidth(pushButton_14->sizePolicy().hasHeightForWidth());
        pushButton_14->setSizePolicy(sizePolicy);
        pushButton_14->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_14->setLayoutDirection(Qt::LeftToRight);
        pushButton_14->setAutoFillBackground(false);
        pushButton_14->setStyleSheet(QStringLiteral("color:rgb(68, 68, 68);border:1px solid rgb(220, 220, 220);border-radius:0;font-size:28px;"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/images/ico/del.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_14->setIcon(icon);
        pushButton_14->setAutoDefault(false);
        pushButton_14->setFlat(true);

        gridLayout->addWidget(pushButton_14, 1, 3, 1, 1);

        pushButton_8 = new QPushButton(gridLayoutWidget);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        sizePolicy.setHeightForWidth(pushButton_8->sizePolicy().hasHeightForWidth());
        pushButton_8->setSizePolicy(sizePolicy);
        pushButton_8->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_8->setLayoutDirection(Qt::LeftToRight);
        pushButton_8->setAutoFillBackground(false);
        pushButton_8->setStyleSheet(QStringLiteral("color:rgb(68, 68, 68);border:1px solid rgb(220, 220, 220);border-radius:0;font-size:28px;"));
        pushButton_8->setAutoDefault(false);

        gridLayout->addWidget(pushButton_8, 2, 1, 1, 1);

        pushButton_11 = new QPushButton(gridLayoutWidget);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        sizePolicy.setHeightForWidth(pushButton_11->sizePolicy().hasHeightForWidth());
        pushButton_11->setSizePolicy(sizePolicy);
        pushButton_11->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_11->setLayoutDirection(Qt::LeftToRight);
        pushButton_11->setAutoFillBackground(false);
        pushButton_11->setStyleSheet(QStringLiteral("color:rgb(68, 68, 68);border:1px solid rgb(220, 220, 220);border-radius:0;font-size:28px;"));
        pushButton_11->setAutoDefault(false);

        gridLayout->addWidget(pushButton_11, 3, 0, 1, 1);

        pushButton_15 = new QPushButton(gridLayoutWidget);
        pushButton_15->setObjectName(QStringLiteral("pushButton_15"));
        sizePolicy.setHeightForWidth(pushButton_15->sizePolicy().hasHeightForWidth());
        pushButton_15->setSizePolicy(sizePolicy);
        pushButton_15->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_15->setLayoutDirection(Qt::LeftToRight);
        pushButton_15->setAutoFillBackground(false);
        pushButton_15->setStyleSheet(QStringLiteral("color:rgb(68, 68, 68);border:1px solid rgb(220, 220, 220);border-radius:0;font-size:28px;"));
        pushButton_15->setAutoDefault(false);

        gridLayout->addWidget(pushButton_15, 3, 2, 1, 1);

        pushButton_6 = new QPushButton(gridLayoutWidget);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        sizePolicy.setHeightForWidth(pushButton_6->sizePolicy().hasHeightForWidth());
        pushButton_6->setSizePolicy(sizePolicy);
        pushButton_6->setContextMenuPolicy(Qt::NoContextMenu);
        pushButton_6->setLayoutDirection(Qt::LeftToRight);
        pushButton_6->setAutoFillBackground(false);
        pushButton_6->setStyleSheet(QStringLiteral("color:rgb(68, 68, 68);border:1px solid rgb(220, 220, 220);border-radius:0;font-size:28px;"));
        pushButton_6->setAutoDefault(false);

        gridLayout->addWidget(pushButton_6, 1, 2, 1, 1);

        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(10, 250, 331, 121));
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        groupBox = new QGroupBox(tab_2);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(70, 10, 120, 80));
        tabWidget->addTab(tab_2, QString());
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        pushButton_13 = new QPushButton(tab);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));
        pushButton_13->setGeometry(QRect(10, 20, 80, 20));
        pushButton_13->setFlat(false);
        comboBox = new QComboBox(tab);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(10, 60, 221, 21));
        tabWidget->addTab(tab, QString());
        widget = new QWidget(centralWidget);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(10, 60, 340, 70));
        widget->setLayoutDirection(Qt::LeftToRight);
        widget->setAutoFillBackground(false);
        widget->setStyleSheet(QStringLiteral("border:1px solid rgb(236, 236, 236)"));
        formLayoutWidget = new QWidget(widget);
        formLayoutWidget->setObjectName(QStringLiteral("formLayoutWidget"));
        formLayoutWidget->setGeometry(QRect(10, 10, 321, 54));
        formLayout = new QFormLayout(formLayoutWidget);
        formLayout->setSpacing(6);
        formLayout->setContentsMargins(11, 11, 11, 11);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        formLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        formLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        formLayout->setRowWrapPolicy(QFormLayout::DontWrapRows);
        formLayout->setLabelAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        formLayout->setFormAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        formLayout->setHorizontalSpacing(6);
        formLayout->setContentsMargins(0, 0, 0, 0);
        Label = new QLabel(formLayoutWidget);
        Label->setObjectName(QStringLiteral("Label"));
        Label->setStyleSheet(QStringLiteral("border:none;background: transparent"));

        formLayout->setWidget(0, QFormLayout::LabelRole, Label);

        LineEdit = new QLineEdit(formLayoutWidget);
        LineEdit->setObjectName(QStringLiteral("LineEdit"));
        LineEdit->setStyleSheet(QLatin1String("border:none;background: transparent;\n"
"font-family: Microsoft YaHei;\n"
"font-size: 30px;\n"
"color: rgb(252, 108, 109);"));
        LineEdit->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout->setWidget(0, QFormLayout::FieldRole, LineEdit);

        widget_2 = new QWidget(centralWidget);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(10, 140, 340, 50));
        QSizePolicy sizePolicy2(QSizePolicy::Ignored, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(widget_2->sizePolicy().hasHeightForWidth());
        widget_2->setSizePolicy(sizePolicy2);
        widget_2->setLayoutDirection(Qt::LeftToRight);
        widget_2->setStyleSheet(QStringLiteral("border:1px solid rgb(236, 236, 236)"));
        formLayoutWidget_2 = new QWidget(widget_2);
        formLayoutWidget_2->setObjectName(QStringLiteral("formLayoutWidget_2"));
        formLayoutWidget_2->setGeometry(QRect(10, 10, 321, 31));
        formLayout_2 = new QFormLayout(formLayoutWidget_2);
        formLayout_2->setSpacing(6);
        formLayout_2->setContentsMargins(11, 11, 11, 11);
        formLayout_2->setObjectName(QStringLiteral("formLayout_2"));
        formLayout_2->setFormAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        formLayout_2->setContentsMargins(0, 0, 0, 0);
        Label_2 = new QLabel(formLayoutWidget_2);
        Label_2->setObjectName(QStringLiteral("Label_2"));
        Label_2->setStyleSheet(QStringLiteral("border:none;background: transparent"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, Label_2);

        LineEdit_2 = new QLineEdit(formLayoutWidget_2);
        LineEdit_2->setObjectName(QStringLiteral("LineEdit_2"));
        LineEdit_2->setStyleSheet(QStringLiteral("border:none;background: transparent"));
        LineEdit_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout_2->setWidget(0, QFormLayout::FieldRole, LineEdit_2);

        widget_3 = new QWidget(centralWidget);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        widget_3->setGeometry(QRect(10, 200, 340, 50));
        sizePolicy2.setHeightForWidth(widget_3->sizePolicy().hasHeightForWidth());
        widget_3->setSizePolicy(sizePolicy2);
        widget_3->setLayoutDirection(Qt::LeftToRight);
        widget_3->setStyleSheet(QStringLiteral("border:1px solid rgb(236, 236, 236)"));
        formLayoutWidget_3 = new QWidget(widget_3);
        formLayoutWidget_3->setObjectName(QStringLiteral("formLayoutWidget_3"));
        formLayoutWidget_3->setGeometry(QRect(10, 10, 321, 31));
        formLayout_3 = new QFormLayout(formLayoutWidget_3);
        formLayout_3->setSpacing(6);
        formLayout_3->setContentsMargins(11, 11, 11, 11);
        formLayout_3->setObjectName(QStringLiteral("formLayout_3"));
        formLayout_3->setFormAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        formLayout_3->setContentsMargins(0, 0, 0, 0);
        Label_3 = new QLabel(formLayoutWidget_3);
        Label_3->setObjectName(QStringLiteral("Label_3"));
        Label_3->setStyleSheet(QStringLiteral("border:none;background: transparent"));

        formLayout_3->setWidget(0, QFormLayout::LabelRole, Label_3);

        LineEdit_3 = new QLineEdit(formLayoutWidget_3);
        LineEdit_3->setObjectName(QStringLiteral("LineEdit_3"));
        LineEdit_3->setStyleSheet(QStringLiteral("border:none;background: transparent"));
        LineEdit_3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout_3->setWidget(0, QFormLayout::FieldRole, LineEdit_3);

        widget_4 = new QWidget(centralWidget);
        widget_4->setObjectName(QStringLiteral("widget_4"));
        widget_4->setGeometry(QRect(0, 0, 701, 40));
        widget_4->setStyleSheet(QStringLiteral("background:rgb(39, 207, 177)"));
        pushButton_16 = new QPushButton(widget_4);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));
        pushButton_16->setGeometry(QRect(660, 0, 40, 40));
        QIcon icon1;
        QString iconThemeName = QStringLiteral("windowClose");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon1 = QIcon::fromTheme(iconThemeName);
        } else {
            icon1.addFile(QStringLiteral(":/images/ico/windowclose.png"), QSize(), QIcon::Normal, QIcon::Off);
            icon1.addFile(QStringLiteral(":/images/ico/windowclose.png"), QSize(), QIcon::Normal, QIcon::On);
        }
        pushButton_16->setIcon(icon1);
        pushButton_16->setIconSize(QSize(18, 18));
        pushButton_16->setFlat(true);
        pushButton_17 = new QPushButton(widget_4);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));
        pushButton_17->setGeometry(QRect(620, 0, 40, 40));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/images/ico/windowcol.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_17->setIcon(icon2);
        pushButton_17->setIconSize(QSize(18, 18));
        pushButton_17->setFlat(true);
        label_4 = new QLabel(widget_4);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(40, 10, 111, 21));
        label_4->setStyleSheet(QLatin1String("font-family:  Microsoft YaHei;\n"
"font-size: 18px;\n"
"color: #FFFFFF;\n"
"letter-spacing: 0;"));
        widget_5 = new QWidget(widget_4);
        widget_5->setObjectName(QStringLiteral("widget_5"));
        widget_5->setGeometry(QRect(0, 0, 40, 40));
        widget_5->setStyleSheet(QStringLiteral("background:url(:/images/window-ico.png) no-repeat center;"));
        MainWindow->setCentralWidget(centralWidget);
        widget_4->raise();
        gridLayoutWidget->raise();
        tabWidget->raise();
        widget->raise();
        widget_2->raise();
        widget_3->raise();

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(1);
        pushButton_13->setDefault(true);
        pushButton_16->setDefault(false);
        pushButton_17->setDefault(false);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton_4->setText(QApplication::translate("MainWindow", "2", nullptr));
        pushButton_5->setText(QApplication::translate("MainWindow", "5", nullptr));
        pushButton_3->setText(QApplication::translate("MainWindow", "3", nullptr));
        pushButton_10->setText(QApplication::translate("MainWindow", "\346\270\205\347\251\272", nullptr));
        pushButton->setText(QApplication::translate("MainWindow", "1", nullptr));
        pushButton_2->setText(QApplication::translate("MainWindow", "4", nullptr));
        pushButton_7->setText(QApplication::translate("MainWindow", "7", nullptr));
        pushButton_12->setText(QApplication::translate("MainWindow", "+", nullptr));
        s->setText(QApplication::translate("MainWindow", "\347\241\256\345\256\232", nullptr));
        pushButton_9->setText(QApplication::translate("MainWindow", "9", nullptr));
        pushButton_14->setText(QString());
        pushButton_8->setText(QApplication::translate("MainWindow", "8", nullptr));
        pushButton_11->setText(QApplication::translate("MainWindow", "0", nullptr));
        pushButton_15->setText(QApplication::translate("MainWindow", ".", nullptr));
        pushButton_6->setText(QApplication::translate("MainWindow", "6", nullptr));
        groupBox->setTitle(QApplication::translate("MainWindow", "GroupBox", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "Tab 2", nullptr));
        pushButton_13->setText(QApplication::translate("MainWindow", "PushButton", nullptr));
        comboBox->setItemText(0, QApplication::translate("MainWindow", "12", nullptr));
        comboBox->setItemText(1, QApplication::translate("MainWindow", "1231231231231", nullptr));
        comboBox->setItemText(2, QApplication::translate("MainWindow", "123123123123123", nullptr));
        comboBox->setItemText(3, QApplication::translate("MainWindow", "123123123123123", nullptr));

        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "Tab 1", nullptr));
        Label->setText(QApplication::translate("MainWindow", "\346\224\266\346\254\276\351\207\221\351\242\235", nullptr));
        LineEdit->setText(QApplication::translate("MainWindow", "121212", nullptr));
        Label_2->setText(QApplication::translate("MainWindow", "\346\224\266\346\254\276\347\240\201", nullptr));
        LineEdit_2->setText(QApplication::translate("MainWindow", "32323", nullptr));
        Label_3->setText(QApplication::translate("MainWindow", "\346\224\266\346\254\276\345\244\207\346\263\250", nullptr));
        LineEdit_3->setText(QApplication::translate("MainWindow", "32323", nullptr));
        pushButton_16->setText(QString());
        pushButton_17->setText(QString());
        label_4->setText(QApplication::translate("MainWindow", "\346\224\266\346\254\276\345\260\217\347\262\276\347\201\265", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
