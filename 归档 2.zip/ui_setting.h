/********************************************************************************
** Form generated from reading UI file 'setting.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTING_H
#define UI_SETTING_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QStackedWidget *stackedWidget;
    QWidget *page_2;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QGroupBox *groupBox;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QLineEdit *lineEdit;
    QLabel *label;
    QCheckBox *checkBox;
    QSpacerItem *horizontalSpacer;
    QGroupBox *groupBox_2;
    QWidget *gridLayoutWidget_2;
    QGridLayout *gridLayout_2;
    QLineEdit *lineEdit_2;
    QCheckBox *checkBox_3;
    QLabel *label_3;
    QCheckBox *checkBox_2;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *horizontalSpacer_3;
    QGroupBox *groupBox_3;
    QWidget *gridLayoutWidget_3;
    QGridLayout *gridLayout_3;
    QPushButton *blueButton;
    QLabel *label_4;
    QLabel *label_5;
    QGroupBox *groupBox_4;
    QWidget *gridLayoutWidget_4;
    QGridLayout *gridLayout_4;
    QLabel *label_6;
    QPushButton *pushButton_7;
    QLabel *label_7;
    QSpacerItem *horizontalSpacer_4;
    QLabel *label_8;
    QComboBox *comboBox;
    QPushButton *pushButton_8;
    QWidget *page_3;
    QWidget *verticalLayoutWidget_3;
    QVBoxLayout *verticalLayout_3;
    QGroupBox *groupBox_5;
    QWidget *gridLayoutWidget_5;
    QGridLayout *gridLayout_5;
    QLabel *label_9;
    QComboBox *comboBox_2;
    QSpacerItem *horizontalSpacer_5;
    QGroupBox *groupBox_6;
    QWidget *gridLayoutWidget_6;
    QGridLayout *gridLayout_6;
    QGridLayout *gridLayout_7;
    QLabel *label_10;
    QComboBox *comboBox_3;
    QSpacerItem *horizontalSpacer_6;
    QGroupBox *groupBox_7;
    QWidget *gridLayoutWidget_8;
    QGridLayout *gridLayout_8;
    QLabel *label_11;
    QLabel *label_12;
    QLineEdit *lineEdit_4;
    QSpacerItem *horizontalSpacer_7;
    QLabel *label_14;
    QSpacerItem *horizontalSpacer_8;
    QComboBox *comboBox_4;
    QComboBox *comboBox_5;
    QLineEdit *lineEdit_3;
    QLabel *label_13;
    QSpacerItem *horizontalSpacer_9;
    QGroupBox *groupBox_8;
    QWidget *gridLayoutWidget_9;
    QGridLayout *gridLayout_9;
    QCheckBox *checkBox_4;
    QCheckBox *checkBox_5;
    QCheckBox *checkBox_6;
    QWidget *page;
    QWidget *verticalLayoutWidget_4;
    QVBoxLayout *verticalLayout_4;
    QGroupBox *groupBox_9;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QFormLayout *formLayout;
    QLabel *label_15;
    QComboBox *comboBox_6;
    QFormLayout *formLayout_2;
    QLabel *label_16;
    QComboBox *comboBox_7;
    QGroupBox *groupBox_10;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QFormLayout *formLayout_3;
    QLabel *label_17;
    QComboBox *comboBox_8;
    QFormLayout *formLayout_6;
    QLabel *Label;
    QComboBox *ComboBox;
    QGroupBox *groupBox_11;
    QWidget *horizontalLayoutWidget_3;
    QHBoxLayout *horizontalLayout_3;
    QFormLayout *formLayout_7;
    QLabel *label_18;
    QComboBox *comboBox_9;
    QLabel *Label_2;
    QComboBox *ComboBox_2;
    QLabel *Label_5;
    QComboBox *ComboBox_5;
    QLabel *Label_6;
    QPushButton *pushButton_9;
    QFormLayout *formLayout_8;
    QLabel *label_19;
    QComboBox *comboBox_10;
    QLabel *Label_3;
    QComboBox *ComboBox_3;
    QLabel *Label_4;
    QComboBox *ComboBox_4;
    QWidget *page_4;
    QWidget *verticalLayoutWidget_5;
    QVBoxLayout *verticalLayout_5;
    QGroupBox *groupBox_12;
    QWidget *formLayoutWidget_5;
    QFormLayout *formLayout_9;
    QLabel *Label_7;
    QComboBox *ComboBox_6;
    QLabel *Label_8;
    QComboBox *ComboBox_7;
    QLabel *Label_9;
    QComboBox *ComboBox_8;
    QLabel *Label_10;
    QComboBox *ComboBox_9;
    QLabel *Label_11;
    QComboBox *ComboBox_10;
    QLabel *Label_12;
    QComboBox *ComboBox_11;
    QLabel *Label_13;
    QComboBox *ComboBox_12;
    QLabel *Label_14;
    QComboBox *ComboBox_13;
    QLabel *Label_15;
    QComboBox *ComboBox_14;
    QWidget *widget;
    QWidget *widget_2;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_2;
    QPushButton *pushButton_5;
    QPushButton *pushButton_4;
    QPushButton *pushButton_6;
    QPushButton *pushButton_3;
    QPushButton *pushButton;
    QPushButton *closeWindow;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QStringLiteral("Dialog"));
        Dialog->resize(700, 400);
        Dialog->setStyleSheet(QStringLiteral("background:rgb(255, 255, 255);border:none"));
        stackedWidget = new QStackedWidget(Dialog);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        stackedWidget->setGeometry(QRect(150, 30, 541, 361));
        stackedWidget->setStyleSheet(QStringLiteral(""));
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        verticalLayoutWidget_2 = new QWidget(page_2);
        verticalLayoutWidget_2->setObjectName(QStringLiteral("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(0, 0, 541, 331));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setSizeConstraint(QLayout::SetNoConstraint);
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        groupBox = new QGroupBox(verticalLayoutWidget_2);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        gridLayoutWidget = new QWidget(groupBox);
        gridLayoutWidget->setObjectName(QStringLiteral("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(0, 20, 541, 41));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        lineEdit = new QLineEdit(gridLayoutWidget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lineEdit->sizePolicy().hasHeightForWidth());
        lineEdit->setSizePolicy(sizePolicy);

        gridLayout->addWidget(lineEdit, 0, 1, 1, 1);

        label = new QLabel(gridLayoutWidget);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        checkBox = new QCheckBox(gridLayoutWidget);
        checkBox->setObjectName(QStringLiteral("checkBox"));

        gridLayout->addWidget(checkBox, 0, 3, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 0, 2, 1, 1);


        verticalLayout_2->addWidget(groupBox);

        groupBox_2 = new QGroupBox(verticalLayoutWidget_2);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        gridLayoutWidget_2 = new QWidget(groupBox_2);
        gridLayoutWidget_2->setObjectName(QStringLiteral("gridLayoutWidget_2"));
        gridLayoutWidget_2->setGeometry(QRect(0, 20, 541, 41));
        gridLayout_2 = new QGridLayout(gridLayoutWidget_2);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        lineEdit_2 = new QLineEdit(gridLayoutWidget_2);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(lineEdit_2->sizePolicy().hasHeightForWidth());
        lineEdit_2->setSizePolicy(sizePolicy1);

        gridLayout_2->addWidget(lineEdit_2, 0, 3, 1, 1);

        checkBox_3 = new QCheckBox(gridLayoutWidget_2);
        checkBox_3->setObjectName(QStringLiteral("checkBox_3"));

        gridLayout_2->addWidget(checkBox_3, 0, 6, 1, 1);

        label_3 = new QLabel(gridLayoutWidget_2);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout_2->addWidget(label_3, 0, 4, 1, 1);

        checkBox_2 = new QCheckBox(gridLayoutWidget_2);
        checkBox_2->setObjectName(QStringLiteral("checkBox_2"));

        gridLayout_2->addWidget(checkBox_2, 0, 0, 1, 1);

        label_2 = new QLabel(gridLayoutWidget_2);
        label_2->setObjectName(QStringLiteral("label_2"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy2);

        gridLayout_2->addWidget(label_2, 0, 2, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer_2, 0, 1, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer_3, 0, 5, 1, 1);


        verticalLayout_2->addWidget(groupBox_2);

        groupBox_3 = new QGroupBox(verticalLayoutWidget_2);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setStyleSheet(QStringLiteral(""));
        gridLayoutWidget_3 = new QWidget(groupBox_3);
        gridLayoutWidget_3->setObjectName(QStringLiteral("gridLayoutWidget_3"));
        gridLayoutWidget_3->setGeometry(QRect(0, 20, 541, 51));
        gridLayout_3 = new QGridLayout(gridLayoutWidget_3);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        blueButton = new QPushButton(gridLayoutWidget_3);
        blueButton->setObjectName(QStringLiteral("blueButton"));

        gridLayout_3->addWidget(blueButton, 1, 1, 1, 1);

        label_4 = new QLabel(gridLayoutWidget_3);
        label_4->setObjectName(QStringLiteral("label_4"));

        gridLayout_3->addWidget(label_4, 0, 0, 1, 1);

        label_5 = new QLabel(gridLayoutWidget_3);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayout_3->addWidget(label_5, 1, 0, 1, 1);


        verticalLayout_2->addWidget(groupBox_3);

        groupBox_4 = new QGroupBox(verticalLayoutWidget_2);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        gridLayoutWidget_4 = new QWidget(groupBox_4);
        gridLayoutWidget_4->setObjectName(QStringLiteral("gridLayoutWidget_4"));
        gridLayoutWidget_4->setGeometry(QRect(0, 20, 541, 61));
        gridLayout_4 = new QGridLayout(gridLayoutWidget_4);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        label_6 = new QLabel(gridLayoutWidget_4);
        label_6->setObjectName(QStringLiteral("label_6"));

        gridLayout_4->addWidget(label_6, 0, 0, 1, 1);

        pushButton_7 = new QPushButton(gridLayoutWidget_4);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));

        gridLayout_4->addWidget(pushButton_7, 0, 3, 1, 1);

        label_7 = new QLabel(gridLayoutWidget_4);
        label_7->setObjectName(QStringLiteral("label_7"));

        gridLayout_4->addWidget(label_7, 0, 1, 1, 1);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer_4, 0, 2, 1, 1);

        label_8 = new QLabel(gridLayoutWidget_4);
        label_8->setObjectName(QStringLiteral("label_8"));

        gridLayout_4->addWidget(label_8, 1, 0, 1, 1);

        comboBox = new QComboBox(gridLayoutWidget_4);
        comboBox->setObjectName(QStringLiteral("comboBox"));

        gridLayout_4->addWidget(comboBox, 1, 1, 1, 1);

        pushButton_8 = new QPushButton(gridLayoutWidget_4);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));

        gridLayout_4->addWidget(pushButton_8, 1, 3, 1, 1);


        verticalLayout_2->addWidget(groupBox_4);

        stackedWidget->addWidget(page_2);
        page_3 = new QWidget();
        page_3->setObjectName(QStringLiteral("page_3"));
        verticalLayoutWidget_3 = new QWidget(page_3);
        verticalLayoutWidget_3->setObjectName(QStringLiteral("verticalLayoutWidget_3"));
        verticalLayoutWidget_3->setGeometry(QRect(0, 0, 541, 351));
        verticalLayout_3 = new QVBoxLayout(verticalLayoutWidget_3);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        groupBox_5 = new QGroupBox(verticalLayoutWidget_3);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        gridLayoutWidget_5 = new QWidget(groupBox_5);
        gridLayoutWidget_5->setObjectName(QStringLiteral("gridLayoutWidget_5"));
        gridLayoutWidget_5->setGeometry(QRect(0, 20, 541, 41));
        gridLayout_5 = new QGridLayout(gridLayoutWidget_5);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        gridLayout_5->setContentsMargins(0, 0, 0, 0);
        label_9 = new QLabel(gridLayoutWidget_5);
        label_9->setObjectName(QStringLiteral("label_9"));

        gridLayout_5->addWidget(label_9, 0, 0, 1, 1);

        comboBox_2 = new QComboBox(gridLayoutWidget_5);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));

        gridLayout_5->addWidget(comboBox_2, 0, 1, 1, 1);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_5->addItem(horizontalSpacer_5, 0, 2, 1, 1);


        verticalLayout_3->addWidget(groupBox_5);

        groupBox_6 = new QGroupBox(verticalLayoutWidget_3);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        gridLayoutWidget_6 = new QWidget(groupBox_6);
        gridLayoutWidget_6->setObjectName(QStringLiteral("gridLayoutWidget_6"));
        gridLayoutWidget_6->setGeometry(QRect(0, 20, 541, 61));
        gridLayout_6 = new QGridLayout(gridLayoutWidget_6);
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        gridLayout_6->setContentsMargins(0, 0, 0, 0);
        gridLayout_7 = new QGridLayout();
        gridLayout_7->setObjectName(QStringLiteral("gridLayout_7"));
        label_10 = new QLabel(gridLayoutWidget_6);
        label_10->setObjectName(QStringLiteral("label_10"));

        gridLayout_7->addWidget(label_10, 0, 0, 1, 1);

        comboBox_3 = new QComboBox(gridLayoutWidget_6);
        comboBox_3->setObjectName(QStringLiteral("comboBox_3"));

        gridLayout_7->addWidget(comboBox_3, 0, 1, 1, 1);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_7->addItem(horizontalSpacer_6, 0, 2, 1, 1);


        gridLayout_6->addLayout(gridLayout_7, 0, 0, 1, 1);


        verticalLayout_3->addWidget(groupBox_6);

        groupBox_7 = new QGroupBox(verticalLayoutWidget_3);
        groupBox_7->setObjectName(QStringLiteral("groupBox_7"));
        gridLayoutWidget_8 = new QWidget(groupBox_7);
        gridLayoutWidget_8->setObjectName(QStringLiteral("gridLayoutWidget_8"));
        gridLayoutWidget_8->setGeometry(QRect(0, 20, 541, 61));
        gridLayout_8 = new QGridLayout(gridLayoutWidget_8);
        gridLayout_8->setObjectName(QStringLiteral("gridLayout_8"));
        gridLayout_8->setContentsMargins(0, 0, 0, 0);
        label_11 = new QLabel(gridLayoutWidget_8);
        label_11->setObjectName(QStringLiteral("label_11"));

        gridLayout_8->addWidget(label_11, 0, 2, 1, 1);

        label_12 = new QLabel(gridLayoutWidget_8);
        label_12->setObjectName(QStringLiteral("label_12"));

        gridLayout_8->addWidget(label_12, 0, 5, 1, 1);

        lineEdit_4 = new QLineEdit(gridLayoutWidget_8);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));

        gridLayout_8->addWidget(lineEdit_4, 0, 9, 1, 1);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_8->addItem(horizontalSpacer_7, 0, 7, 1, 1);

        label_14 = new QLabel(gridLayoutWidget_8);
        label_14->setObjectName(QStringLiteral("label_14"));

        gridLayout_8->addWidget(label_14, 0, 10, 1, 1);

        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_8->addItem(horizontalSpacer_8, 0, 4, 1, 1);

        comboBox_4 = new QComboBox(gridLayoutWidget_8);
        comboBox_4->setObjectName(QStringLiteral("comboBox_4"));

        gridLayout_8->addWidget(comboBox_4, 0, 0, 1, 1);

        comboBox_5 = new QComboBox(gridLayoutWidget_8);
        comboBox_5->setObjectName(QStringLiteral("comboBox_5"));

        gridLayout_8->addWidget(comboBox_5, 0, 3, 1, 1);

        lineEdit_3 = new QLineEdit(gridLayoutWidget_8);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));

        gridLayout_8->addWidget(lineEdit_3, 0, 6, 1, 1);

        label_13 = new QLabel(gridLayoutWidget_8);
        label_13->setObjectName(QStringLiteral("label_13"));

        gridLayout_8->addWidget(label_13, 0, 8, 1, 1);

        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_8->addItem(horizontalSpacer_9, 0, 1, 1, 1);


        verticalLayout_3->addWidget(groupBox_7);

        groupBox_8 = new QGroupBox(verticalLayoutWidget_3);
        groupBox_8->setObjectName(QStringLiteral("groupBox_8"));
        gridLayoutWidget_9 = new QWidget(groupBox_8);
        gridLayoutWidget_9->setObjectName(QStringLiteral("gridLayoutWidget_9"));
        gridLayoutWidget_9->setGeometry(QRect(0, 19, 541, 91));
        gridLayout_9 = new QGridLayout(gridLayoutWidget_9);
        gridLayout_9->setObjectName(QStringLiteral("gridLayout_9"));
        gridLayout_9->setContentsMargins(0, 0, 0, 0);
        checkBox_4 = new QCheckBox(gridLayoutWidget_9);
        checkBox_4->setObjectName(QStringLiteral("checkBox_4"));

        gridLayout_9->addWidget(checkBox_4, 0, 0, 1, 1);

        checkBox_5 = new QCheckBox(gridLayoutWidget_9);
        checkBox_5->setObjectName(QStringLiteral("checkBox_5"));

        gridLayout_9->addWidget(checkBox_5, 0, 1, 1, 1);

        checkBox_6 = new QCheckBox(gridLayoutWidget_9);
        checkBox_6->setObjectName(QStringLiteral("checkBox_6"));

        gridLayout_9->addWidget(checkBox_6, 0, 2, 1, 1);


        verticalLayout_3->addWidget(groupBox_8);

        stackedWidget->addWidget(page_3);
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        verticalLayoutWidget_4 = new QWidget(page);
        verticalLayoutWidget_4->setObjectName(QStringLiteral("verticalLayoutWidget_4"));
        verticalLayoutWidget_4->setGeometry(QRect(0, 0, 541, 361));
        verticalLayout_4 = new QVBoxLayout(verticalLayoutWidget_4);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        verticalLayout_4->setSizeConstraint(QLayout::SetDefaultConstraint);
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        groupBox_9 = new QGroupBox(verticalLayoutWidget_4);
        groupBox_9->setObjectName(QStringLiteral("groupBox_9"));
        horizontalLayoutWidget_2 = new QWidget(groupBox_9);
        horizontalLayoutWidget_2->setObjectName(QStringLiteral("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(0, 23, 541, 31));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        formLayout = new QFormLayout();
        formLayout->setObjectName(QStringLiteral("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        formLayout->setContentsMargins(0, -1, -1, -1);
        label_15 = new QLabel(horizontalLayoutWidget_2);
        label_15->setObjectName(QStringLiteral("label_15"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label_15);

        comboBox_6 = new QComboBox(horizontalLayoutWidget_2);
        comboBox_6->setObjectName(QStringLiteral("comboBox_6"));

        formLayout->setWidget(0, QFormLayout::FieldRole, comboBox_6);


        horizontalLayout_2->addLayout(formLayout);

        formLayout_2 = new QFormLayout();
        formLayout_2->setObjectName(QStringLiteral("formLayout_2"));
        formLayout_2->setHorizontalSpacing(6);
        label_16 = new QLabel(horizontalLayoutWidget_2);
        label_16->setObjectName(QStringLiteral("label_16"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_16);

        comboBox_7 = new QComboBox(horizontalLayoutWidget_2);
        comboBox_7->setObjectName(QStringLiteral("comboBox_7"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, comboBox_7);


        horizontalLayout_2->addLayout(formLayout_2);


        verticalLayout_4->addWidget(groupBox_9);

        groupBox_10 = new QGroupBox(verticalLayoutWidget_4);
        groupBox_10->setObjectName(QStringLiteral("groupBox_10"));
        horizontalLayoutWidget = new QWidget(groupBox_10);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(0, 20, 541, 31));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        formLayout_3 = new QFormLayout();
        formLayout_3->setObjectName(QStringLiteral("formLayout_3"));
        label_17 = new QLabel(horizontalLayoutWidget);
        label_17->setObjectName(QStringLiteral("label_17"));

        formLayout_3->setWidget(0, QFormLayout::LabelRole, label_17);

        comboBox_8 = new QComboBox(horizontalLayoutWidget);
        comboBox_8->addItem(QString());
        comboBox_8->addItem(QString());
        comboBox_8->setObjectName(QStringLiteral("comboBox_8"));

        formLayout_3->setWidget(0, QFormLayout::FieldRole, comboBox_8);


        horizontalLayout->addLayout(formLayout_3);

        formLayout_6 = new QFormLayout();
        formLayout_6->setObjectName(QStringLiteral("formLayout_6"));
        Label = new QLabel(horizontalLayoutWidget);
        Label->setObjectName(QStringLiteral("Label"));

        formLayout_6->setWidget(0, QFormLayout::LabelRole, Label);

        ComboBox = new QComboBox(horizontalLayoutWidget);
        ComboBox->setObjectName(QStringLiteral("ComboBox"));

        formLayout_6->setWidget(0, QFormLayout::FieldRole, ComboBox);


        horizontalLayout->addLayout(formLayout_6);


        verticalLayout_4->addWidget(groupBox_10);

        groupBox_11 = new QGroupBox(verticalLayoutWidget_4);
        groupBox_11->setObjectName(QStringLiteral("groupBox_11"));
        horizontalLayoutWidget_3 = new QWidget(groupBox_11);
        horizontalLayoutWidget_3->setObjectName(QStringLiteral("horizontalLayoutWidget_3"));
        horizontalLayoutWidget_3->setGeometry(QRect(0, 20, 541, 135));
        horizontalLayout_3 = new QHBoxLayout(horizontalLayoutWidget_3);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        formLayout_7 = new QFormLayout();
        formLayout_7->setObjectName(QStringLiteral("formLayout_7"));
        formLayout_7->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        formLayout_7->setVerticalSpacing(11);
        formLayout_7->setContentsMargins(0, -1, -1, -1);
        label_18 = new QLabel(horizontalLayoutWidget_3);
        label_18->setObjectName(QStringLiteral("label_18"));

        formLayout_7->setWidget(0, QFormLayout::LabelRole, label_18);

        comboBox_9 = new QComboBox(horizontalLayoutWidget_3);
        comboBox_9->setObjectName(QStringLiteral("comboBox_9"));

        formLayout_7->setWidget(0, QFormLayout::FieldRole, comboBox_9);

        Label_2 = new QLabel(horizontalLayoutWidget_3);
        Label_2->setObjectName(QStringLiteral("Label_2"));

        formLayout_7->setWidget(1, QFormLayout::LabelRole, Label_2);

        ComboBox_2 = new QComboBox(horizontalLayoutWidget_3);
        ComboBox_2->setObjectName(QStringLiteral("ComboBox_2"));

        formLayout_7->setWidget(1, QFormLayout::FieldRole, ComboBox_2);

        Label_5 = new QLabel(horizontalLayoutWidget_3);
        Label_5->setObjectName(QStringLiteral("Label_5"));

        formLayout_7->setWidget(2, QFormLayout::LabelRole, Label_5);

        ComboBox_5 = new QComboBox(horizontalLayoutWidget_3);
        ComboBox_5->addItem(QString());
        ComboBox_5->addItem(QString());
        ComboBox_5->addItem(QString());
        ComboBox_5->setObjectName(QStringLiteral("ComboBox_5"));

        formLayout_7->setWidget(2, QFormLayout::FieldRole, ComboBox_5);

        Label_6 = new QLabel(horizontalLayoutWidget_3);
        Label_6->setObjectName(QStringLiteral("Label_6"));

        formLayout_7->setWidget(3, QFormLayout::LabelRole, Label_6);

        pushButton_9 = new QPushButton(horizontalLayoutWidget_3);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));

        formLayout_7->setWidget(3, QFormLayout::FieldRole, pushButton_9);


        horizontalLayout_3->addLayout(formLayout_7);

        formLayout_8 = new QFormLayout();
        formLayout_8->setObjectName(QStringLiteral("formLayout_8"));
        formLayout_8->setHorizontalSpacing(6);
        formLayout_8->setVerticalSpacing(10);
        formLayout_8->setContentsMargins(-1, 0, -1, -1);
        label_19 = new QLabel(horizontalLayoutWidget_3);
        label_19->setObjectName(QStringLiteral("label_19"));

        formLayout_8->setWidget(0, QFormLayout::LabelRole, label_19);

        comboBox_10 = new QComboBox(horizontalLayoutWidget_3);
        comboBox_10->setObjectName(QStringLiteral("comboBox_10"));

        formLayout_8->setWidget(0, QFormLayout::FieldRole, comboBox_10);

        Label_3 = new QLabel(horizontalLayoutWidget_3);
        Label_3->setObjectName(QStringLiteral("Label_3"));

        formLayout_8->setWidget(1, QFormLayout::LabelRole, Label_3);

        ComboBox_3 = new QComboBox(horizontalLayoutWidget_3);
        ComboBox_3->setObjectName(QStringLiteral("ComboBox_3"));

        formLayout_8->setWidget(1, QFormLayout::FieldRole, ComboBox_3);

        Label_4 = new QLabel(horizontalLayoutWidget_3);
        Label_4->setObjectName(QStringLiteral("Label_4"));

        formLayout_8->setWidget(2, QFormLayout::LabelRole, Label_4);

        ComboBox_4 = new QComboBox(horizontalLayoutWidget_3);
        ComboBox_4->addItem(QString());
        ComboBox_4->addItem(QString());
        ComboBox_4->addItem(QString());
        ComboBox_4->addItem(QString());
        ComboBox_4->setObjectName(QStringLiteral("ComboBox_4"));

        formLayout_8->setWidget(2, QFormLayout::FieldRole, ComboBox_4);


        horizontalLayout_3->addLayout(formLayout_8);


        verticalLayout_4->addWidget(groupBox_11);

        stackedWidget->addWidget(page);
        page_4 = new QWidget();
        page_4->setObjectName(QStringLiteral("page_4"));
        verticalLayoutWidget_5 = new QWidget(page_4);
        verticalLayoutWidget_5->setObjectName(QStringLiteral("verticalLayoutWidget_5"));
        verticalLayoutWidget_5->setGeometry(QRect(0, 0, 541, 361));
        verticalLayout_5 = new QVBoxLayout(verticalLayoutWidget_5);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        groupBox_12 = new QGroupBox(verticalLayoutWidget_5);
        groupBox_12->setObjectName(QStringLiteral("groupBox_12"));
        formLayoutWidget_5 = new QWidget(groupBox_12);
        formLayoutWidget_5->setObjectName(QStringLiteral("formLayoutWidget_5"));
        formLayoutWidget_5->setGeometry(QRect(0, 20, 331, 341));
        formLayout_9 = new QFormLayout(formLayoutWidget_5);
        formLayout_9->setObjectName(QStringLiteral("formLayout_9"));
        formLayout_9->setVerticalSpacing(16);
        formLayout_9->setContentsMargins(0, 0, 0, 0);
        Label_7 = new QLabel(formLayoutWidget_5);
        Label_7->setObjectName(QStringLiteral("Label_7"));

        formLayout_9->setWidget(0, QFormLayout::LabelRole, Label_7);

        ComboBox_6 = new QComboBox(formLayoutWidget_5);
        ComboBox_6->setObjectName(QStringLiteral("ComboBox_6"));

        formLayout_9->setWidget(0, QFormLayout::FieldRole, ComboBox_6);

        Label_8 = new QLabel(formLayoutWidget_5);
        Label_8->setObjectName(QStringLiteral("Label_8"));

        formLayout_9->setWidget(1, QFormLayout::LabelRole, Label_8);

        ComboBox_7 = new QComboBox(formLayoutWidget_5);
        ComboBox_7->setObjectName(QStringLiteral("ComboBox_7"));

        formLayout_9->setWidget(1, QFormLayout::FieldRole, ComboBox_7);

        Label_9 = new QLabel(formLayoutWidget_5);
        Label_9->setObjectName(QStringLiteral("Label_9"));

        formLayout_9->setWidget(2, QFormLayout::LabelRole, Label_9);

        ComboBox_8 = new QComboBox(formLayoutWidget_5);
        ComboBox_8->setObjectName(QStringLiteral("ComboBox_8"));

        formLayout_9->setWidget(2, QFormLayout::FieldRole, ComboBox_8);

        Label_10 = new QLabel(formLayoutWidget_5);
        Label_10->setObjectName(QStringLiteral("Label_10"));

        formLayout_9->setWidget(3, QFormLayout::LabelRole, Label_10);

        ComboBox_9 = new QComboBox(formLayoutWidget_5);
        ComboBox_9->setObjectName(QStringLiteral("ComboBox_9"));

        formLayout_9->setWidget(3, QFormLayout::FieldRole, ComboBox_9);

        Label_11 = new QLabel(formLayoutWidget_5);
        Label_11->setObjectName(QStringLiteral("Label_11"));

        formLayout_9->setWidget(4, QFormLayout::LabelRole, Label_11);

        ComboBox_10 = new QComboBox(formLayoutWidget_5);
        ComboBox_10->setObjectName(QStringLiteral("ComboBox_10"));

        formLayout_9->setWidget(4, QFormLayout::FieldRole, ComboBox_10);

        Label_12 = new QLabel(formLayoutWidget_5);
        Label_12->setObjectName(QStringLiteral("Label_12"));

        formLayout_9->setWidget(5, QFormLayout::LabelRole, Label_12);

        ComboBox_11 = new QComboBox(formLayoutWidget_5);
        ComboBox_11->setObjectName(QStringLiteral("ComboBox_11"));

        formLayout_9->setWidget(5, QFormLayout::FieldRole, ComboBox_11);

        Label_13 = new QLabel(formLayoutWidget_5);
        Label_13->setObjectName(QStringLiteral("Label_13"));

        formLayout_9->setWidget(6, QFormLayout::LabelRole, Label_13);

        ComboBox_12 = new QComboBox(formLayoutWidget_5);
        ComboBox_12->setObjectName(QStringLiteral("ComboBox_12"));

        formLayout_9->setWidget(6, QFormLayout::FieldRole, ComboBox_12);

        Label_14 = new QLabel(formLayoutWidget_5);
        Label_14->setObjectName(QStringLiteral("Label_14"));

        formLayout_9->setWidget(7, QFormLayout::LabelRole, Label_14);

        ComboBox_13 = new QComboBox(formLayoutWidget_5);
        ComboBox_13->setObjectName(QStringLiteral("ComboBox_13"));

        formLayout_9->setWidget(7, QFormLayout::FieldRole, ComboBox_13);

        Label_15 = new QLabel(formLayoutWidget_5);
        Label_15->setObjectName(QStringLiteral("Label_15"));

        formLayout_9->setWidget(8, QFormLayout::LabelRole, Label_15);

        ComboBox_14 = new QComboBox(formLayoutWidget_5);
        ComboBox_14->setObjectName(QStringLiteral("ComboBox_14"));

        formLayout_9->setWidget(8, QFormLayout::FieldRole, ComboBox_14);


        verticalLayout_5->addWidget(groupBox_12);

        stackedWidget->addWidget(page_4);
        widget = new QWidget(Dialog);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(-1, 0, 141, 401));
        widget->setStyleSheet(QStringLiteral("background-color:rgb(248, 248, 248)"));
        widget_2 = new QWidget(widget);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(0, 0, 141, 141));
        widget_2->setStyleSheet(QStringLiteral("background:url(:/images/logo-setting.png) no-repeat center top;"));
        verticalLayoutWidget = new QWidget(widget);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(0, 140, 141, 261));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_2 = new QPushButton(verticalLayoutWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setEnabled(true);
        QSizePolicy sizePolicy3(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(pushButton_2->sizePolicy().hasHeightForWidth());
        pushButton_2->setSizePolicy(sizePolicy3);
        pushButton_2->setLayoutDirection(Qt::LeftToRight);
        pushButton_2->setStyleSheet(QStringLiteral("text-align:left;padding-left:14px;"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/images/siderico/set.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_2->setIcon(icon);
        pushButton_2->setAutoRepeatInterval(98);
        pushButton_2->setFlat(true);

        verticalLayout->addWidget(pushButton_2);

        pushButton_5 = new QPushButton(verticalLayoutWidget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setEnabled(true);
        sizePolicy3.setHeightForWidth(pushButton_5->sizePolicy().hasHeightForWidth());
        pushButton_5->setSizePolicy(sizePolicy3);
        pushButton_5->setLayoutDirection(Qt::LeftToRight);
        pushButton_5->setStyleSheet(QStringLiteral("text-align:left;padding-left:14px;"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/images/siderico/money.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_5->setIcon(icon1);
        pushButton_5->setAutoRepeatInterval(98);
        pushButton_5->setFlat(true);

        verticalLayout->addWidget(pushButton_5);

        pushButton_4 = new QPushButton(verticalLayoutWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setEnabled(true);
        sizePolicy3.setHeightForWidth(pushButton_4->sizePolicy().hasHeightForWidth());
        pushButton_4->setSizePolicy(sizePolicy3);
        pushButton_4->setLayoutDirection(Qt::LeftToRight);
        pushButton_4->setStyleSheet(QStringLiteral("text-align:left;padding-left:14px;"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/images/siderico/comp.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_4->setIcon(icon2);
        pushButton_4->setAutoRepeatInterval(98);
        pushButton_4->setFlat(true);

        verticalLayout->addWidget(pushButton_4);

        pushButton_6 = new QPushButton(verticalLayoutWidget);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setEnabled(true);
        sizePolicy3.setHeightForWidth(pushButton_6->sizePolicy().hasHeightForWidth());
        pushButton_6->setSizePolicy(sizePolicy3);
        pushButton_6->setLayoutDirection(Qt::LeftToRight);
        pushButton_6->setStyleSheet(QStringLiteral("text-align:left;padding-left:14px;"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/images/siderico/keybord.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_6->setIcon(icon3);
        pushButton_6->setAutoRepeatInterval(152);
        pushButton_6->setFlat(true);

        verticalLayout->addWidget(pushButton_6);

        pushButton_3 = new QPushButton(verticalLayoutWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setEnabled(true);
        sizePolicy3.setHeightForWidth(pushButton_3->sizePolicy().hasHeightForWidth());
        pushButton_3->setSizePolicy(sizePolicy3);
        pushButton_3->setLayoutDirection(Qt::LeftToRight);
        pushButton_3->setStyleSheet(QStringLiteral("text-align:left;padding-left:14px;"));
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/images/siderico/network.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_3->setIcon(icon4);
        pushButton_3->setAutoRepeatInterval(98);
        pushButton_3->setFlat(true);

        verticalLayout->addWidget(pushButton_3);

        pushButton = new QPushButton(verticalLayoutWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setEnabled(true);
        sizePolicy3.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy3);
        pushButton->setLayoutDirection(Qt::LeftToRight);
        pushButton->setStyleSheet(QStringLiteral("text-align:left;padding-left:14px;"));
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/images/siderico/help.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton->setIcon(icon5);
        pushButton->setAutoRepeatInterval(98);
        pushButton->setFlat(true);

        verticalLayout->addWidget(pushButton);

        closeWindow = new QPushButton(Dialog);
        closeWindow->setObjectName(QStringLiteral("closeWindow"));
        closeWindow->setGeometry(QRect(670, 0, 30, 30));
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/images/ico/close.png"), QSize(), QIcon::Normal, QIcon::Off);
        closeWindow->setIcon(icon6);

        retranslateUi(Dialog);

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Dialog", nullptr));
        groupBox->setTitle(QApplication::translate("Dialog", "\347\225\214\351\235\242\346\230\276\347\244\272\350\256\276\347\275\256", nullptr));
        label->setText(QApplication::translate("Dialog", "\346\224\266\346\254\276\346\265\256\347\252\227\357\274\232", nullptr));
        checkBox->setText(QApplication::translate("Dialog", "\346\230\276\347\244\272\346\224\266\346\254\276\345\244\207\346\263\250", nullptr));
        groupBox_2->setTitle(QApplication::translate("Dialog", "\345\274\200\346\234\272\350\256\276\347\275\256", nullptr));
        checkBox_3->setText(QApplication::translate("Dialog", "\350\207\252\345\212\250\347\231\273\351\231\206\345\260\217\347\262\276\347\201\265", nullptr));
        label_3->setText(QApplication::translate("Dialog", "\346\257\253\347\247\222", nullptr));
        checkBox_2->setText(QApplication::translate("Dialog", "\345\274\200\346\234\272\345\220\257\345\212\250\345\260\217\347\262\276\347\201\265", nullptr));
        label_2->setText(QApplication::translate("Dialog", "\345\273\266\346\227\266\345\220\257\345\212\250\345\260\217\347\262\276\347\201\265", nullptr));
        groupBox_3->setTitle(QApplication::translate("Dialog", "\347\231\273\351\231\206\344\277\241\346\201\257", nullptr));
        blueButton->setText(QApplication::translate("Dialog", "\351\207\215\347\275\256\345\257\206\347\240\201", nullptr));
        label_4->setText(QApplication::translate("Dialog", "\351\227\250\345\272\227\345\220\215\357\274\232\350\245\277\345\260\221\347\210\267\346\234\233\344\272\254SOHO\345\272\227", nullptr));
        label_5->setText(QApplication::translate("Dialog", "\347\231\273\345\275\225\345\220\215\357\274\232xishaoye001", nullptr));
        groupBox_4->setTitle(QApplication::translate("Dialog", "\346\254\276\345\217\260\344\277\241\346\201\257", nullptr));
        label_6->setText(QApplication::translate("Dialog", "\346\254\276\345\217\260\347\274\226\345\217\267\357\274\232", nullptr));
        pushButton_7->setText(QApplication::translate("Dialog", "\347\224\237\346\210\220\347\274\226\347\240\201", nullptr));
        label_7->setText(QApplication::translate("Dialog", "uweiq129319231231023", nullptr));
        label_8->setText(QApplication::translate("Dialog", "\346\254\276\345\217\260\345\220\215\347\247\260\357\274\232", nullptr));
        pushButton_8->setText(QApplication::translate("Dialog", "\344\277\235\345\255\230\350\256\276\347\275\256", nullptr));
        groupBox_5->setTitle(QApplication::translate("Dialog", "\346\224\266\346\254\276\351\207\221\351\242\235\346\212\223\345\217\226\350\256\276\347\275\256", nullptr));
        label_9->setText(QApplication::translate("Dialog", "\346\212\223\345\217\226\346\250\241\345\274\217\357\274\232", nullptr));
        groupBox_6->setTitle(QApplication::translate("Dialog", "\346\224\266\346\254\276\345\217\202\346\225\260\350\256\276\347\275\256", nullptr));
        label_10->setText(QApplication::translate("Dialog", "\346\224\266\346\254\276\346\250\241\345\274\217\357\274\232", nullptr));
        groupBox_7->setTitle(QApplication::translate("Dialog", "\350\241\245\346\214\211\345\277\253\346\215\267\351\224\256\350\256\276\347\275\256", nullptr));
        label_11->setText(QApplication::translate("Dialog", "\345\277\253\346\215\267\351\224\256\351\200\211\346\213\251\357\274\232", nullptr));
        label_12->setText(QApplication::translate("Dialog", "\345\233\236\350\275\246\346\225\260\357\274\232", nullptr));
        label_14->setText(QApplication::translate("Dialog", "\346\257\253\347\247\222", nullptr));
        label_13->setText(QApplication::translate("Dialog", "\346\214\211\351\224\256\351\227\264\351\232\224\357\274\232", nullptr));
        groupBox_8->setTitle(QApplication::translate("Dialog", "\346\224\266\346\254\276\346\226\271\345\274\217\350\256\276\347\275\256", nullptr));
        checkBox_4->setText(QApplication::translate("Dialog", "\345\276\256\344\277\241\346\224\257\344\273\230", nullptr));
        checkBox_5->setText(QApplication::translate("Dialog", "\346\224\257\344\273\230\345\256\235\346\224\257\344\273\230", nullptr));
        checkBox_6->setText(QApplication::translate("Dialog", "\345\260\217\347\262\276\347\201\265\344\274\232\345\221\230\347\224\265\345\255\220\346\224\257\344\273\230", nullptr));
        groupBox_9->setTitle(QApplication::translate("Dialog", "\346\211\253\347\240\201\350\256\276\345\244\207", nullptr));
        label_15->setText(QApplication::translate("Dialog", "\346\211\253\347\240\201\350\256\276\345\244\207\347\261\273\345\236\213\357\274\232", nullptr));
        label_16->setText(QApplication::translate("Dialog", "\346\211\253\347\240\201\350\256\276\345\244\207\347\261\273\345\236\213\357\274\232", nullptr));
        groupBox_10->setTitle(QApplication::translate("Dialog", "\346\211\223\345\215\260\350\275\254\346\216\245\350\256\276\347\275\256", nullptr));
        label_17->setText(QApplication::translate("Dialog", "\350\275\254\346\216\245\346\250\241\345\274\217\357\274\232", nullptr));
        comboBox_8->setItemText(0, QApplication::translate("Dialog", "\346\226\260\345\273\272\351\241\271\347\233\256", nullptr));
        comboBox_8->setItemText(1, QApplication::translate("Dialog", "\346\226\260\345\273\272\351\241\271\347\233\256", nullptr));

        Label->setText(QApplication::translate("Dialog", "\344\270\262\345\217\243\347\253\257\351\200\211\346\213\251\357\274\232", nullptr));
        groupBox_11->setTitle(QApplication::translate("Dialog", "\345\260\217\347\245\250\346\234\272\350\256\276\347\275\256", nullptr));
        label_18->setText(QApplication::translate("Dialog", "\346\211\253\347\240\201\350\256\276\345\244\207\347\261\273\345\236\213\357\274\232", nullptr));
        Label_2->setText(QApplication::translate("Dialog", "\344\270\262\345\217\243\346\263\242\347\211\271\347\216\207\351\200\211\346\213\251:", nullptr));
        Label_5->setText(QApplication::translate("Dialog", "\346\211\223\345\215\260\344\273\275\346\225\260\357\274\232", nullptr));
        ComboBox_5->setItemText(0, QApplication::translate("Dialog", "1", nullptr));
        ComboBox_5->setItemText(1, QApplication::translate("Dialog", "2", nullptr));
        ComboBox_5->setItemText(2, QApplication::translate("Dialog", "3", nullptr));

        Label_6->setText(QString());
        pushButton_9->setText(QApplication::translate("Dialog", "\346\211\223\345\215\260\346\265\213\350\257\225\345\260\217\347\245\250", nullptr));
        label_19->setText(QApplication::translate("Dialog", "\346\211\253\347\240\201\350\256\276\345\244\207\347\261\273\345\236\213\357\274\232", nullptr));
        Label_3->setText(QApplication::translate("Dialog", "\345\260\217\347\245\250\347\272\270\345\236\213\345\217\267\357\274\232", nullptr));
        Label_4->setText(QApplication::translate("Dialog", "\345\260\217\347\245\250\350\265\260\347\272\270\350\241\214\346\225\260", nullptr));
        ComboBox_4->setItemText(0, QApplication::translate("Dialog", "1", nullptr));
        ComboBox_4->setItemText(1, QApplication::translate("Dialog", "2", nullptr));
        ComboBox_4->setItemText(2, QApplication::translate("Dialog", "3", nullptr));
        ComboBox_4->setItemText(3, QApplication::translate("Dialog", "4", nullptr));

        groupBox_12->setTitle(QApplication::translate("Dialog", "\345\277\253\346\215\267\351\224\256\350\256\276\347\275\256", nullptr));
        Label_7->setText(QApplication::translate("Dialog", "\346\230\276\347\244\272\345\277\253\346\215\267\351\224\256\350\257\264\346\230\216\357\274\232", nullptr));
        Label_8->setText(QApplication::translate("Dialog", "\346\211\223\345\274\200\345\205\263\351\227\255\346\224\266\351\223\266\345\217\260\357\274\232", nullptr));
        Label_9->setText(QApplication::translate("Dialog", "\351\200\200\346\254\276\357\274\232", nullptr));
        Label_10->setText(QApplication::translate("Dialog", "\347\216\260\351\207\221\346\224\266\346\254\276\357\274\232", nullptr));
        Label_11->setText(QApplication::translate("Dialog", "\345\210\267\345\215\241\346\224\266\346\254\276\357\274\232", nullptr));
        Label_12->setText(QApplication::translate("Dialog", "\344\274\232\345\221\230\346\224\266\346\254\276\357\274\232", nullptr));
        Label_13->setText(QApplication::translate("Dialog", "\344\272\244\346\230\223\346\237\245\350\257\242\357\274\232", nullptr));
        Label_14->setText(QApplication::translate("Dialog", "\344\272\244\346\216\245\347\217\255(\346\263\250\351\224\200)\357\274\232", nullptr));
        Label_15->setText(QApplication::translate("Dialog", "\345\205\263\351\227\255\345\260\217\347\262\276\347\201\265\357\274\232", nullptr));
        pushButton_2->setText(QApplication::translate("Dialog", "\345\270\270\350\247\204\350\256\276\347\275\256", nullptr));
        pushButton_5->setText(QApplication::translate("Dialog", "\346\224\266\351\223\266\350\256\276\347\275\256", nullptr));
        pushButton_4->setText(QApplication::translate("Dialog", "\345\244\226\350\256\276\351\205\215\347\275\256", nullptr));
        pushButton_6->setText(QApplication::translate("Dialog", "\345\277\253\346\215\267\351\224\256\350\256\276\347\275\256", nullptr));
        pushButton_3->setText(QApplication::translate("Dialog", "\344\273\243\347\220\206\347\275\221\347\273\234\350\256\276\347\275\256", nullptr));
        pushButton->setText(QApplication::translate("Dialog", "\351\253\230\347\272\247\350\256\276\347\275\256", nullptr));
        closeWindow->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTING_H
